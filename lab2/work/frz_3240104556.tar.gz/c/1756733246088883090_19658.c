This is a random .c file #1
